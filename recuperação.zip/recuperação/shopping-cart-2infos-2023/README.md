# Shopping Cart (Carrinho de compras)

Exemplo para aplicação de conceitos de Vue 3, a serem utilizados como exemplos nas aulas de Desenvolvimento Web II.

## Instalação

```sh
npm install
```

### Execução em modo de desenvolvimento

```sh
npm run dev
```

### Compilação para produção

```sh
npm run build
```
