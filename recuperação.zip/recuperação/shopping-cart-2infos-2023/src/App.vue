<script setup>
import { ref } from 'vue'
import { livros } from '@/_data/livros.js'
import { adicionarAoCarrinho } from '@/_data/carrinho.js'

import cardLivro from './components/cardLivro.vue';

import meuCarrinho from './components/meuCarrinho.vue';

</script>

<template>
  <h1>Minha livraria</h1>
  <div class="container-geral">
    <div class="listagem-livros">
    <card-livro v-for="livro in livros" :key="livro.id" v-bind:livro="livro" @adicionarAoCarrinho="adicionarAoCarrinho"/>
    </div>
    <meuCarrinho />
  </div>
</template>

<style scoped>

.container-geral {
  /* display: flex;
  justify-content: space-between; */
  display: grid;
  grid-template-columns: 3fr 1fr;
}

.listagem-livros {
  display: flex;
  flex-wrap: wrap;
}
</style>
