<template>
    <p>Seu carrinho está vazio :(</p>
</template>

<style scoped>
p {
    font-size: 1.1rem;
    font-weight: bold;
}
</style>