<script setup>
import listagemLivros from './components/listagemLivros.vue';
import meuCarrinho from './components/meuCarrinho.vue';

</script>

<template>
<h1>Minha livraria</h1>
<div class="container-geral">
<listagemLivros />
<meuCarrinho />
</div>

</template>

<style scoped>

.container-geral {
  /* display: flex;
  justify-content: space-between; */
  display: grid;
  grid-template-columns: 3fr 1fr;
}
</style>